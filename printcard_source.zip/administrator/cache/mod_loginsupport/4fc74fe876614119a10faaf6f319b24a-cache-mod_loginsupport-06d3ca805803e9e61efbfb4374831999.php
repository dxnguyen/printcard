<?php die("Access Denied"); ?>#x#a:2:{s:6:"result";s:907:"<div class="col-md-12 module-wrapper">
    <div class="card pt-3">
                            <h3 class="card-header">Need Support?</h3>
                <div class="module-body">
            <section class="loginsupport">
    <p>You can find help here:</p>
    <ul class="list-unstyled">
        <li>
            <a href="https://forum.joomla.org/" target="_blank" rel="nofollow noopener" title="Open Joomla! Support Forum in new window">Joomla! Support Forum</a>        </li>
        <li>
            <a href="https://docs.joomla.org/" target="_blank" rel="nofollow noopener" title="Open Joomla! Documentation in new window">Joomla! Documentation</a>        </li>
        <li>
            <a href="https://www.joomla.org/announcements.html" target="_blank" rel="nofollow noopener" title="Open Joomla! News in new window">Joomla! News</a>        </li>
    </ul>
</section>
        </div>
    </div>
</div>
";s:6:"output";a:2:{s:4:"body";s:0:"";s:4:"head";a:2:{s:10:"scriptText";a:3:{s:13:"JSHOWPASSWORD";s:13:"Show Password";s:13:"JHIDEPASSWORD";s:13:"Hide Password";s:19:"JGLOBAL_WARNCOOKIES";s:69:"Warning! Cookies must be enabled to access the Administrator Backend.";}s:12:"assetManager";a:2:{s:13:"registryFiles";a:5:{i:0;s:30:"media\vendor\joomla.asset.json";i:1;s:30:"media\system\joomla.asset.json";i:2;s:30:"media\legacy\joomla.asset.json";i:3;s:46:"media\plg_system_guidedtours\joomla.asset.json";i:4;s:46:"administrator\templates\atum\joomla.asset.json";}s:6:"assets";a:0:{}}}}}