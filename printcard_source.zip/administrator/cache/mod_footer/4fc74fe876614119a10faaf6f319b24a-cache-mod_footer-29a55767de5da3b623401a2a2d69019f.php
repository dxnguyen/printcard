<?php die("Access Denied"); ?>#x#a:2:{s:6:"result";s:224:"<div class="mod-footer">
    <div class="footer1">Bản quyền©2024 thuộc Trung tâm Quản lý Ký túc xá ĐHQG-HCM.</div>
    <p class="hotline text-center">Phone: 1900.055.559 -  Email: ktx@vnuhcm.edu.vn</p>
</div>
";s:6:"output";a:2:{s:4:"body";s:0:"";s:4:"head";a:1:{s:12:"assetManager";a:2:{s:13:"registryFiles";a:6:{i:0;s:30:"media\vendor\joomla.asset.json";i:1;s:30:"media\system\joomla.asset.json";i:2;s:30:"media\legacy\joomla.asset.json";i:3;s:46:"media\plg_system_guidedtours\joomla.asset.json";i:4;s:36:"media\com_students\joomla.asset.json";i:5;s:39:"templates\studentcard\joomla.asset.json";}s:6:"assets";a:0:{}}}}}