DROP TABLE IF EXISTS `#__buildings`;
