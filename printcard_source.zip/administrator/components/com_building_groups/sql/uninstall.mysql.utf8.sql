DROP TABLE IF EXISTS `#__building_groups`;
